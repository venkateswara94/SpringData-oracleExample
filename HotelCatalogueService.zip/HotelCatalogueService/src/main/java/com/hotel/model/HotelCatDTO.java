package com.hotel.model;

public class HotelCatDTO {

	private int hcat_id;

	private String hname;

	private String city;

	private String item;

	public HotelCatDTO() {}
	
	public HotelCatDTO(int hcat_id, String hname, String city, String item) {
		super();
		this.hcat_id = hcat_id;
		this.hname = hname;
		this.city = city;
		this.item = item;
	}

	public int getHcat_id() {
		return hcat_id;
	}

	public void setHcat_id(int hcat_id) {
		this.hcat_id = hcat_id;
	}

	public String getHname() {
		return hname;
	}

	public void setHname(String hname) {
		this.hname = hname;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getItem() {
		return item;
	}

	public void setItem(String item) {
		this.item = item;
	}

	@Override
	public String toString() {
		return "HotelCatDTO [hcat_id=" + hcat_id + ", hname=" + hname + ", city=" + city + ", item=" + item + "]";
	}
	
	

}
