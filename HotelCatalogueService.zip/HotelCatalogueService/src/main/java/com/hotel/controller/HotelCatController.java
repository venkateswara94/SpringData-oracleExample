package com.hotel.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hotel.model.HotelCatDTO;
import com.hotel.service.HotelCatSearvice;

@RestController
@RequestMapping("/hotel")
public class HotelCatController {
	
	@Autowired
	HotelCatSearvice service;

	@Value("${server.port}")
	private String serverPort;
	
	
	@RequestMapping("/")
	public String getMsg() {
		return "<h1 align='center'>Welcome to MyHotel</h1><h2 bgcolor='khaki'><a href='http://localhost:"+serverPort+"/swagger-ui.html'>Swagger Dashboard</a></h2> ";
	}
	
	
	@RequestMapping("/getHotels")
	public List<HotelCatDTO> getHotelCats(){
		return service.getHotelCats();
	}
	
	
	
	@RequestMapping(value = "/addHotel", method = RequestMethod.POST)
	public String addHotel(@RequestBody HotelCatDTO reqDTO){
		
		return service.addHotel(reqDTO);
	}
	
	@RequestMapping(value = "/updateHotel", method = RequestMethod.PUT)
	public String updateHotel(@RequestBody HotelCatDTO reqDTO){
		
		return service.updateHotel(reqDTO);
	}
	
	
	@RequestMapping(value = "/deleteHotel", method = RequestMethod.DELETE)
	public String deleteHotel(@RequestParam String htId){
		
		return service.deleteHotel(htId);
	}
	
	@RequestMapping(value = "/findHotel", method = RequestMethod.GET)
	public HotelCatDTO findHotel(@RequestParam String htId){
		
		return service.findHotelById(htId);
	}
	
	
}
