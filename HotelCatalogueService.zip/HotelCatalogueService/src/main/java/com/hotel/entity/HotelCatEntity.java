package com.hotel.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="hotel_cat")
public class HotelCatEntity {
	
	
	@Id
   // @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "emp_seq")
    //@SequenceGenerator(initialValue = 1, name = "emp_seq", sequenceName = "employee_sequence")
	@GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "hcat_id")
	private Integer hcat_id;
	
	@Column(name = "hname")
	private String hname;
	
	private String city;
	
	private String item;

	public HotelCatEntity() {
		
	}
	
	public HotelCatEntity(Integer hcat_id, String hname, String city, String item) {
		super();
		this.hcat_id = hcat_id;
		this.hname = hname;
		this.city = city;
		this.item = item;
	}

	public Integer getHcat_id() {
		return hcat_id;
	}

	public void setHcat_id(Integer hcat_id) {
		this.hcat_id = hcat_id;
	}

	public String getHname() {
		return hname;
	}

	public void setHname(String hname) {
		this.hname = hname;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getItem() {
		return item;
	}

	public void setItem(String item) {
		this.item = item;
	}

	@Override
	public String toString() {
		return "HotelCatEntity [hcat_id=" + hcat_id + ", hname=" + hname + ", city=" + city + ", item=" + item + "]";
	}
	
}
