package com.hotel.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hotel.entity.HotelCatEntity;
import com.hotel.model.HotelCatDTO;
import com.hotel.repository.HotelCatRepository;

@Service
public class HotelCatSearvice {

	@Autowired
	HotelCatRepository repository;

	public List<HotelCatDTO> getHotelCats() {

		List<HotelCatEntity> listEntities =  repository.findAll();
		listEntities.forEach(System.out::println);
		
		return listEntities.stream().map(db->{
			HotelCatDTO response = new HotelCatDTO();
			response.setHcat_id(db.getHcat_id());
			response.setCity(db.getCity());
			response.setHname(db.getHname());
			response.setItem(db.getItem());
			return response;
		}).collect(Collectors.toList());

	}

	public String addHotel(HotelCatDTO reqDTO) {
		HotelCatEntity entity = 
				new HotelCatEntity(reqDTO.getHcat_id(),reqDTO.getHname(),reqDTO.getCity(),reqDTO.getItem());
		HotelCatEntity entity2 = repository.saveAndFlush(entity);
		return (entity2.getHcat_id()!=null || entity2.getHcat_id()!=0) ? "Record saved Successfully!":"Failed to save record..!";
	}
	
	public String updateHotel(HotelCatDTO reqDTO) {
		
		if(reqDTO.getHcat_id()!=0){
			Optional<HotelCatEntity> entity = repository.findById(reqDTO.getHcat_id());
			
			if(entity!=null) {
				HotelCatEntity entity2 = 
						new HotelCatEntity(reqDTO.getHcat_id(),reqDTO.getHname(),reqDTO.getCity(),reqDTO.getItem());
				HotelCatEntity entity3 = repository.save(entity2);
				return (entity2.getHcat_id()!=null || entity2.getHcat_id()!=0) ? "Record saved Successfully!":"Failed to save record..!";
			}
		}
		return "Failed to Update the record with id: "+reqDTO.getHcat_id();
	}

	public String deleteHotel(String htId) {
		if(htId!=null && htId!="") {
		int htcId = Integer.valueOf(htId);
		repository.deleteById(htcId);
		return "Record Deleted Successfully";
		}else
		{
			return "Record not available";
		}
		
	}
	
	public HotelCatDTO findHotelById(String htId) {
		if(htId!=null && htId!="") {
		int htcId = Integer.valueOf(htId);
		Optional<HotelCatEntity> entity =  repository.findById(htcId);
		
		if(entity.isPresent()) {
			HotelCatEntity	resentity = entity.get();
			HotelCatDTO response = new HotelCatDTO(resentity.getHcat_id(),resentity.getHname(),resentity.getCity(),resentity.getItem());
			return response;
		}
		}
		return null;		
	}

}
