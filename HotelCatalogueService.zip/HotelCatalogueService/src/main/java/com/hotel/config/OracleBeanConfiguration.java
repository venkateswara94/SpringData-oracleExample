package com.hotel.config;

import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import oracle.jdbc.pool.OracleDataSource;

@Configuration
public class OracleBeanConfiguration {
	
	@Value("${spring.datasource.url}")
	private String url;
	
	@Value("${spring.datasource.username}")
	private String userName;
	
	@Value("${spring.datasource.password}")
	private String password;
	
	@Bean
    public DataSource dataSource() throws SQLException {
		/*
		 * PoolDataSource dataSource = PoolDataSourceFactory.getPoolDataSource();
		 * dataSource.setUser("books"); dataSource.setPassword("books");
		 * dataSource.setConnectionFactoryClassName("oracle.jdbc.pool.OracleDataSource")
		 * ; dataSource.setURL("jdbc:oracle:thin:@//localhost:11521/ORCLPDB1");
		 * dataSource.setFastConnectionFailoverEnabled(true);
		 * dataSource.setInitialPoolSize(5); dataSource.setMinPoolSize(5);
		 * dataSource.setMaxPoolSize(10); return dataSource;
		 */
		
		OracleDataSource datasource = new OracleDataSource();
		/*
		 * datasource.setURL("jdbc:oracle:thin:@localhost:1521:xe");
		 * datasource.setUser("system"); datasource.setPassword("tiger");
		 */
		datasource.setURL(url);
		datasource.setUser(userName);
		datasource.setPassword(password);
		datasource.setImplicitCachingEnabled(true);
		datasource.setFastConnectionFailoverEnabled(true);
		return datasource;
    }

}
